package com.toqueauto.app

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var bar: LinearLayout? = null
    private lateinit var playBtn: TextView
    private val targets = mutableListOf<TextView>()
    private var running = false
    private var idx = 0
    private var multi = false
    private var interval = 500L
    private var reps = 0

    private val step = object : Runnable {
        override fun run() {
            if (!running) return
            val svc = ClickService.instance
            if (svc == null || targets.isEmpty()) { stop(); return }
            val t = targets[idx % targets.size]
            val p = t.layoutParams as WindowManager.LayoutParams
            svc.tap(p.x + t.width / 2f, p.y + t.height / 2f)
            idx++
            if (reps > 0 && idx >= reps * targets.size) { stop(); return }
            h.postDelayed(this, interval)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        cleanup()
        multi = i?.getStringExtra("mode") == "multi"
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        interval = maxOf(100, p.getInt("iv", 500)).toLong()
        reps = p.getInt("rp", 0)
        buildBar()
        addTarget()
        return START_NOT_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun params(w: Int, ht: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, ht, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun button(t: String, a: () -> Unit) = TextView(this).apply {
        text = t; textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        setOnClickListener { a() }
    }

    private fun buildBar() {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E614231F")); cornerRadius = dp(14).toFloat()
            }
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        playBtn = button("▶") { toggle() }
        b.addView(playBtn)
        b.addView(button("+") { addTarget() })
        b.addView(button("−") { removeTarget() })
        b.addView(button("⚙") {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        val mv = button("✥") {}
        b.addView(mv)
        b.addView(button("✕") { stopSelf() })
        wm.addView(b, params(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, dp(8), dp(160)))
        makeDraggable(mv, b)
        bar = b
    }

    private fun addTarget() {
        if (!multi && targets.isNotEmpty()) return
        val n = targets.size
        val t = TextView(this).apply {
            text = (n + 1).toString(); textSize = 16f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#802DD4BF"))
                setStroke(dp(3), Color.parseColor("#2DD4BF"))
            }
        }
        wm.addView(t, params(dp(52), dp(52), dp(120) + n * dp(56), dp(300) + n * dp(40)))
        makeDraggable(t, t)
        targets.add(t)
    }

    private fun removeTarget() {
        if (running) return
        val t = targets.removeLastOrNull() ?: return
        wm.removeView(t)
    }

    private fun makeDraggable(handle: View, target: View) {
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        handle.setOnTouchListener { _, e ->
            val p = target.layoutParams as WindowManager.LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - dx).toInt()
                    p.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(target, p)
                }
            }
            true
        }
    }

    private fun setTouchable(on: Boolean) {
        for (t in targets) {
            val p = t.layoutParams as WindowManager.LayoutParams
            p.flags = if (on) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(t, p)
        }
    }

    private fun toggle() { if (running) stop() else start() }

    private fun start() {
        if (targets.isEmpty()) return
        running = true; idx = 0; playBtn.text = "■"
        setTouchable(false)
        h.post(step)
    }

    private fun stop() {
        running = false; h.removeCallbacks(step); playBtn.text = "▶"
        setTouchable(true)
    }

    private fun cleanup() {
        running = false; h.removeCallbacks(step)
        targets.forEach { try { wm.removeView(it) } catch (e: Exception) {} }
        targets.clear()
        bar?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        bar = null
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }
}
