package com.toqueauto.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun label(t: String, s: Float = 16f) = TextView(this).apply {
            text = t; textSize = s; setPadding(0, pad / 2, 0, pad / 4)
        }
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { a() }
        }

        root.addView(label("ToqueAuto", 28f))
        status = label("")
        root.addView(status)
        root.addView(btn("1. Permitir sobreposição na tela") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("2. Ativar acessibilidade do ToqueAuto") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        val iv = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(p.getInt("iv", 500).toString())
        }
        val rp = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(p.getInt("rp", 0).toString())
        }
        root.addView(label("Intervalo entre toques (ms, mínimo 100)"))
        root.addView(iv)
        root.addView(label("Repetições da sequência (0 = sem limite)"))
        root.addView(rp)

        fun go(mode: String) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Falta permitir a sobreposição (passo 1).", Toast.LENGTH_LONG).show(); return
            }
            if (ClickService.instance == null) {
                Toast.makeText(this, "Falta ativar a acessibilidade (passo 2).", Toast.LENGTH_LONG).show(); return
            }
            p.edit()
                .putInt("iv", iv.text.toString().toIntOrNull() ?: 500)
                .putInt("rp", rp.text.toString().toIntOrNull() ?: 0)
                .apply()
            startService(Intent(this, OverlayService::class.java).putExtra("mode", mode))
            moveTaskToBack(true)
        }
        root.addView(btn("Ativar alvo único") { go("single") })
        root.addView(btn("Ativar vários alvos") { go("multi") })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val ov = if (Settings.canDrawOverlays(this)) "ok" else "falta"
        val ac = if (ClickService.instance != null) "ok" else "falta"
        status.text = "Sobreposição: $ov\nAcessibilidade: $ac"
    }
}
